/*
#########################################################################
#########################################################################
Low Cost Signal Generator 
By Parker Osborne 

Designed to be used with a Raspberry Pi Pico 2W and AD9959
#########################################################################
#########################################################################
*/

#include "system_lcg_v2.h"
#include "hardware/pio.h"
#include "pseudoclock_15mhz.pio.h"
#include <stdlib.h>

#define SWEEP_US 51000 
void pseudoclock_init(PIO pio, uint sm, uint pin) {
    uint offset = pio_add_program(pio, &pseudoclock_15mhz_program);

    pio_gpio_init(pio, pin);
    pio_sm_set_consecutive_pindirs(pio, sm, pin, 1, true);

    pio_sm_config c = pseudoclock_15mhz_program_get_default_config(offset);
    sm_config_set_sideset_pins(&c, pin);
    sm_config_set_sideset(&c, 1, false, false);

    sm_config_set_clkdiv(&c, 1.0f);   // full sys_clk resolution, no fractional jitter

    // sharper electrical edges — actual rise/fall time, separate from PIO timing
    gpio_set_drive_strength(pin, GPIO_DRIVE_STRENGTH_4MA);
    gpio_set_slew_rate(pin, GPIO_SLEW_RATE_SLOW);

    pio_sm_init(pio, sm, offset, &c);
    pio_sm_set_enabled(pio, sm, true);

}

void control_pins_init(void) {
    const uint pins[] = { PIN_MASTER_RESET, PIN_IO_UPDATE,
                          PIN_P0, PIN_P1, PIN_P2, PIN_P3 };
    for (uint i = 0; i < count_of(pins); i++) {
        gpio_init(pins[i]);
        gpio_set_dir(pins[i], GPIO_OUT);
        gpio_put(pins[i], 0);
    }
}

int main()
{
    sleep_ms(1);
    stdio_init_all();
    control_pins_init();
    
    gpio_put(PIN_MASTER_RESET,1);
    sleep_ms(1);
    gpio_put(PIN_MASTER_RESET,0);

    // SPI initialisation. This example will use SPI at 1MHz.
    spi_init(SPI_PORT, 1000*1000);
    gpio_set_function(PIN_MISO, GPIO_FUNC_SPI);
    gpio_set_function(PIN_CS,   GPIO_FUNC_SIO);
    gpio_set_function(PIN_SCK,  GPIO_FUNC_SPI);
    gpio_set_function(PIN_MOSI, GPIO_FUNC_SPI);
    
    // Chip select is active-low, so we'll initialise it to a driven-high state
    gpio_set_dir(PIN_CS, GPIO_OUT);
    gpio_put(PIN_CS, 1);

    uint8_t data = 0xDD;
    size_t data_len = sizeof(data);
    pseudoclock_init(pio0, 0, CLOCK_OUT_PIN);

    sleep_ms(2000);             //let USB CDC enumerate before the first printf
    AD9959_init();

    uint32_t f = 100000000;
    f_tune(CH0_SELECT, f);
    printf("tone at %lu Hz. type a frequency in Hz and press enter.\n", f);

    char line[32];
    uint8_t n = 0;
  
while (true){
    int c = getchar_timeout_us(1000);
    if (c == PICO_ERROR_TIMEOUT) continue;

    printf("[rx %d]\n", c);          //TEMP: delete once it works
    fflush(stdout);

    if (c == '\r' || c == '\n'){
        if (n > 0){
            line[n] = '\0';
            uint32_t newf = strtoul(line, NULL, 10);
            if (newf > 0){
                f = newf;
                f_tune(CH0_SELECT, f);
                printf("\ntone at %lu Hz\n", f);
            } else {
                printf("\nbad input: %s\n", line);
            }
            fflush(stdout);
            n = 0;
        }
    } else if (n < sizeof(line) - 1){
        line[n++] = (char)c;
        putchar(c);
        fflush(stdout);
    }
}
   
}