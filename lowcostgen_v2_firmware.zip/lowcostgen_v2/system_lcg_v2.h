
/* 
##########################################################################################
##########################################################################################

System Header for Low Cost Generator V2
Created by Parker Osborne 

Designed to be used with a Raspberry Pi Pico 2W, and an AD9959 DDS synthesizer chip. 

##########################################################################################
##########################################################################################
*/

#include <stdio.h>
#include "pico/stdlib.h"
#include "hardware/clocks.h"
#include "hardware/spi.h"
#include <string.h>


#ifndef system_lcg_v2
#define system_lcg_v2

#define AD9959_SERIAL_MODE 0x02
#define AD9959_CLOCK 500000000
#define AD9959_SYNC_CLOCKMHz 125 //sys clock/4
#define SPI_PORT spi0
#define CLOCK_OUT_PIN 15
#define PIN_MISO 16
#define PIN_CS   17
#define PIN_SCK  18
#define PIN_MOSI 19
#define PIN_MASTER_RESET 2 //connects to pin 3 of the AD9959
#define PIN_IO_UPDATE 0 //connects to pin 46 of AD9959

#define PIN_P0 6    //conects to PIN 40 on AD9959
#define PIN_P1 7    //conects to PIN 41 on AD9959
#define PIN_P2 8    //conects to PIN 42 on AD9959
#define PIN_P3 9    //conects to PIN 43 on AD9959


#define CSR_W 0x00      //Channel Select Register ----------------- 1B
#define CSR_R 0x80      
#define FR1_W 0x01      //Function Register 1 --------------------- 3B
#define FR1_R 0x81
#define FR2_W 0x02      //Function Register 2 --------------------- 2B
#define FR2_R 0x82
#define CFR_W 0x03      //Channel Function Register --------------- 3B
#define CFR_R 0x83
#define CFTW0_W 0x04    //Channel Frequency Tuning Word 0 --------- 4B
#define CFTW0_R 0x85
#define CPOW0_W 0x05    //Channel Phase Offset Word 0 ------------- 2B
#define CPOW0_R 0x85
#define ACR_W 0x06      //Amplitude Control Register -------------- 3B
#define ACR_R 0x86
#define LSRR_W 0x07     //Linear Sweep Ramp Rate ------------------ 2B
#define LSRR_R 0x87
#define RDW_W 0x08      //LSR Rising Delta Word ------------------- 4B
#define RDW_R 0x88
#define FDW_W 0x09      //LSR Falling Delta Word ------------------ 4B
#define FDW_R 0x89
#define CW1_W 0x0A      //Channel Word 1(E0) -------------------------- 4B(freq) / 14b(phase) / 10b(amp) / unused bits are dont care
#define CW1_R 0x8A

//predefined data for common functions 
#define CH0_SELECT 0x12
#define CH1_SELECT 0x22
#define CH2_SELECT 0x42
#define CH3_SELECT 0x82

#define DWELL_ON 1
#define DWELL_OFF 0
#define SWEEP_UP 1
#define SWEEP_DOWN 0


/*
@brief Enables communication with the AD9959 via SPI communication.
Sets CS to low (active).
*/
void cs_select(){
    //sets CS low to enable communication with chip
    gpio_put(PIN_CS, 0);
}

/*
@brief Sets chip select pin to high, disabling communication with AD9959.
This resets the bit counter in SPI and the address/instruction cycle.
*/
void cs_deselect(){
    //sets CS high to disable communication with chip 
    gpio_put(PIN_CS, 1);
}
/*
@brief
Triggers I/O update pin on AD9959.
Writes 1 to pin, pauses for 1us and the writes a 0 
This will cause all channels to update and preload modulation signals.
*/
void IO_update(){
   gpio_put(PIN_IO_UPDATE,1);
   sleep_us(1);
   gpio_put(PIN_IO_UPDATE,0);
}


void AD9959_write_register(uint8_t addr, const uint8_t *data, size_t len) {
    uint8_t buf[5]; // max register width on AD9959 is 4 bytes + 1 instruction byte
    buf[0] = addr;  
    memcpy(&buf[1], data, len); //copys data to to the buffer
    cs_select(); // enable communication 
    spi_write_blocking(SPI_PORT, buf, len + 1);
    cs_deselect();
}

//normal write register only works for 1 byte, this will work for larger registers 
void AD9959_write_register_u32(uint8_t addr, uint32_t value, size_t len) {
    uint8_t data[4];
    for (size_t i = 0; i < len; i++) {
        data[i] = (uint8_t)(value >> (8 * (len - 1 - i))); // MSB first
    }
    AD9959_write_register(addr, data, len);
}

/*
@brief Finds correct tuning word based on  desired input frequency
@param desired_f desired freq up to fsys 
*/
uint32_t frequency_helper(uint32_t desired_f){

    return (uint32_t)(((uint64_t)desired_f << 32) / AD9959_CLOCK);

}

/*
@brief Writes function to desired channel. Does not trigger I/O Update.
@param Holds address of channel. Use predefined addresses in system header.
@param Holds desired frequency to be tuned
*/
void f_tune(uint32_t channel, uint32_t freq){
    //simple function to set tune 
    AD9959_write_register_u32(CSR_W, channel, 1);
    AD9959_write_register_u32(CFTW0_W, frequency_helper(freq), 4);
    IO_update();
}

/*
Direct modulation of amplitude for 2 level modulation mode. AFP bits set to 01. Linear sweep disabled.


*/






void AD9959_init(){
    //initiate a master reset before initialization
    gpio_put(PIN_MASTER_RESET, 1);
    sleep_ms(1);
    gpio_put(PIN_MASTER_RESET, 0);
    cs_select();
    //step 1, setup clock multiplier. Targeting 500MHz which is 20x based clock from the RPi
    //At 300 MHz VCO bit 23 must be toggled high in FR1
    AD9959_write_register_u32(FR1_W, 0xD00000, 3);
    //Step 2, write to CSR (0x00) to enable CH 0 and set the SPI mode to 01
    f_tune(CH0_SELECT, 1000000);
    f_tune(CH1_SELECT, 1000000);
    f_tune(CH2_SELECT, 1000000);
    f_tune(CH3_SELECT, 1000000);

    cs_deselect();
    
}
/*


*/
void configure_sweep_mode(){

}

/*

*/
void configure_mod_mode(){

}



/*
@brief Programs and triggers a linear sweep on a specific channel.
@param channel Channel Address CHX_SELECT
@param f_start Start Frequency 
@param f_stop Stop Frequency 
@param step Step Size in Hz 
@param rate_ns Step rate must be between 14 and 3400 in steps of 14
@param dwell 0 for no dwell, 1 for dwell
@param dir 0 for down, 1 for up 
*/



//profile pins indexed 0-3. in linear sweep mode P0->CH0, P1->CH1, P2->CH2, P3->CH3
const uint8_t profile_pin[4] = {PIN_P0, PIN_P1, PIN_P2, PIN_P3};

void linear_sweep_f(uint8_t channel , uint32_t f_start, uint32_t f_stop, uint32_t step, uint32_t rate_ns, bool dwell, bool dir) {
//the rate must be entered in nanoseconds and in the range from 8ns to 2040ns (only works in steps of 8ns)
//channel is the CSR mask (0x10=CH0, 0x20=CH1, 0x40=CH2, 0x80=CH3)
//mask to the high nibble and shift down to 0-3 to pick the matching profile pin
uint8_t P_pin = profile_pin[__builtin_ctz(channel & 0xF0) - 4];
//load S0 and E0 (start and stop values)
//f_tune selects the channel in the CSR and it stays selected for the writes below
f_tune(channel, f_start);
AD9959_write_register_u32(CW1_W, frequency_helper(f_stop), 4);
//set the parameter to sweep in the CFR to freq
//bit 14 = linear sweep enable, bit 15 = no-dwell
//bits 9:8 = DAC full scale current, 11 = full. zeroing these drops the output to 1/8
if (dwell){
    AD9959_write_register_u32(CFR_W, 0x804300, 3);
} else {
    AD9959_write_register_u32(CFR_W, 0x80C300, 3);
}
//calculate step tuning word and load to both RDW and FDW
//both are needed: RDW is used sweeping up to E0, FDW sweeping back down to S0
AD9959_write_register_u32(RDW_W, frequency_helper(step), 4);
AD9959_write_register_u32(FDW_W, frequency_helper(step), 4);
//calculate speed and load into LSRR, 2 bytes only: FSSR in [15:8], RSSR in [7:0]
uint8_t RSSR = (rate_ns * AD9959_SYNC_CLOCKMHz)/1000;
uint8_t FSSR = RSSR;
AD9959_write_register_u32(LSRR_W, ((uint16_t)FSSR << 8) | RSSR, 2);
//latch all changes before triggering
IO_update();
//trigger sweep with the profile pin for this channel
//sweep starts on the pin transition, not the level, so the pin must already be in
//the opposite state for this to fire. it then stays put for the whole sweep.
if (dir){
    gpio_put(P_pin, 1);

} else {
    gpio_put(P_pin, 0);
}

}

void linear_sweep_a(){

}

void linear_sweep_p(){

}

#endif